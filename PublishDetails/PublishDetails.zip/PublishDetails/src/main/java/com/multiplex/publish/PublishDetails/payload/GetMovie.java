package com.multiplex.publish.PublishDetails.payload;

import lombok.Data;
@Data
public class GetMovie {
    private String MovieName;
    private Long MovieId;
}
