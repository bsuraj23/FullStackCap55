package com.multiplex.publish.PublishDetails.security;

import com.multiplex.publish.PublishDetails.entity.ShowType;
import com.multiplex.publish.PublishDetails.entity.Show;
import com.multiplex.publish.PublishDetails.repository.ShowsRepository;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Collections;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private ShowsRepository showsRepository;

    private ShowType showType;

    public CustomUserDetailsService(ShowsRepository showsRepository) {
        this.showsRepository=showsRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String MovieName) throws UsernameNotFoundException {
        Show show = showsRepository.findbyMovie(MovieName)
                .orElseThrow(() ->
                        new UsernameNotFoundException("User not found with username or email:" + MovieName));
        //return new org.springframework.security.core.userdetails.User(user.getEmail(),user.getPassword(),Authorities());
        return null;
    }

    private Collection< ? extends GrantedAuthority> Authorities(){
        return Collections.singleton(new SimpleGrantedAuthority("USER"));
    }
}