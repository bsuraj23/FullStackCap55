package com.multiplex.publish.PublishDetails.entity;

public enum ShowType {
    ADMIN,
    USER
}
