package com.multiplex.publish.PublishDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PublishDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
